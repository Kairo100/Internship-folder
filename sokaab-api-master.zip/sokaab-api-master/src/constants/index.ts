export const platformEntity = 2; // Sokaab
